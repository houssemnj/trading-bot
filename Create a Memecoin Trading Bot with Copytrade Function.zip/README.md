# Bot de Trading de Memecoins avec Fonction de Copytrade

Ce projet est un bot de trading automatisé spécialisé dans les memecoins avec une fonctionnalité de copytrade qui permet de suivre et de reproduire les transactions d'autres traders.

## Fonctionnalités

- Trading automatisé de memecoins sur plusieurs plateformes d'échange (Binance, Coinbase, Kraken)
- Fonction de copytrade pour suivre et reproduire les transactions d'autres traders
- Analyse technique des memecoins
- Gestion des risques avec stop-loss et take-profit automatiques
- Mode simulation (dry run) pour tester sans risquer de fonds réels
- Notifications configurables pour les événements importants
- Interface en ligne de commande simple et efficace

## Prérequis

- Python 3.10 ou supérieur
- Pip (gestionnaire de paquets Python)
- Accès à Internet
- Comptes sur les plateformes d'échange supportées (optionnel pour le mode simulation)

## Installation

1. Clonez ce dépôt sur votre machine locale :
```bash
git clone https://github.com/votre-username/trading-bot.git
cd trading-bot
```

2. Exécutez le script d'installation :
```bash
chmod +x install.sh
./install.sh
```

Ce script va :
- Créer un environnement virtuel Python
- Installer toutes les dépendances nécessaires
- Exécuter les tests pour vérifier que tout fonctionne correctement
- Créer les répertoires nécessaires pour les logs et les données

## Configuration

Avant d'utiliser le bot, vous devez configurer vos clés API et vos préférences de trading dans le fichier `src/config.py`.

### Configuration des clés API

Vous pouvez configurer vos clés API de deux façons :

1. Directement dans le fichier `src/config.py` (non recommandé pour des raisons de sécurité)
2. Via des variables d'environnement (recommandé) :

```bash
export BINANCE_API_KEY="votre_clé_api_binance"
export BINANCE_API_SECRET="votre_clé_secrète_binance"
export COINBASE_API_KEY="votre_clé_api_coinbase"
export COINBASE_API_SECRET="votre_clé_secrète_coinbase"
export COINBASE_API_PASSPHRASE="votre_passphrase_coinbase"
export KRAKEN_API_KEY="votre_clé_api_kraken"
export KRAKEN_API_SECRET="votre_clé_secrète_kraken"
```

### Configuration du trading

Modifiez les paramètres suivants dans `src/config.py` selon vos préférences :

- `TRADING_CONFIG` : Configuration générale du trading (plateforme par défaut, montant par trade, etc.)
- `TRADING_PAIRS` : Paires de trading à surveiller sur chaque plateforme
- `COPYTRADE_CONFIG` : Configuration de la fonction de copytrade (traders à suivre, allocation, etc.)
- `NOTIFICATION_CONFIG` : Configuration des notifications
- `LOGGING_CONFIG` : Configuration de la journalisation

## Utilisation

### Démarrer le bot

```bash
chmod +x start_bot.sh
./start_bot.sh
```

Le bot commencera à surveiller les marchés et à exécuter des trades selon la configuration définie.

### Arrêter le bot

```bash
chmod +x stop_bot.sh
./stop_bot.sh
```

### Mode simulation

Par défaut, le bot est configuré pour fonctionner en mode simulation (`dry_run: True` dans `TRADING_CONFIG`). Dans ce mode, aucun ordre réel n'est placé sur les plateformes d'échange.

Pour passer en mode réel, modifiez `dry_run: False` dans `TRADING_CONFIG`. **Attention** : en mode réel, le bot placera des ordres avec vos fonds réels.

## Fonction de Copytrade

La fonction de copytrade permet de suivre et de reproduire automatiquement les transactions d'autres traders.

### Ajouter un trader à suivre

Modifiez la section `followed_traders` dans `COPYTRADE_CONFIG` :

```python
"followed_traders": [
    {"id": "trader1", "exchange": "binance", "allocation_pct": 30},
    {"id": "trader2", "exchange": "binance", "allocation_pct": 40},
    {"id": "trader3", "exchange": "kraken", "allocation_pct": 30},
],
```

Vous pouvez également ajouter des traders programmatiquement :

```python
from src.meme_trader import MemeTrader

bot = MemeTrader()
bot.add_trader_to_follow(
    trader_id="trader123",
    exchange="binance",
    allocation_pct=30.0,
    metadata={"name": "Trader Expert", "description": "Trader spécialisé dans les memecoins"}
)
```

### Paramètres de copytrade

- `max_traders_to_follow` : Nombre maximum de traders à suivre
- `min_trader_reputation` : Score minimum de réputation pour suivre un trader
- `max_copy_stake_pct` : Pourcentage maximum du capital à allouer au copytrade
- `auto_adjust_position_size` : Ajuster automatiquement la taille des positions
- `delay_seconds` : Délai en secondes avant de copier un trade

## Structure du projet

```
trading_bot/
├── src/                    # Code source du bot
│   ├── config.py           # Configuration du bot
│   ├── trading_bot.py      # Classe principale du bot de trading
│   ├── copytrade.py        # Module de copytrade
│   └── meme_trader.py      # Intégration du bot et du module de copytrade
├── tests/                  # Tests unitaires
│   └── test_trading_bot.py # Tests pour le bot
├── logs/                   # Fichiers de log
├── data/                   # Données et historique
├── install.sh              # Script d'installation
├── start_bot.sh            # Script de démarrage du bot
├── stop_bot.sh             # Script d'arrêt du bot
└── requirements.txt        # Dépendances Python
```

## Dépannage

### Le bot ne se connecte pas aux plateformes d'échange

- Vérifiez que vos clés API sont correctes et ont les permissions nécessaires
- Vérifiez votre connexion Internet
- Consultez les logs dans `logs/trading_bot.log` pour plus de détails

### Erreurs lors de l'installation

- Vérifiez que vous avez Python 3.10 ou supérieur installé
- Vérifiez que vous avez les droits d'administrateur pour installer les dépendances
- Sur certains systèmes, vous pourriez avoir besoin d'installer des packages supplémentaires :
  ```bash
  sudo apt-get install build-essential python3-dev
  ```

### Le bot ne place pas d'ordres

- Vérifiez que le mode simulation (`dry_run`) est désactivé dans `TRADING_CONFIG`
- Vérifiez que vous avez suffisamment de fonds sur votre compte
- Consultez les logs pour plus de détails

## Avertissement

Le trading de cryptomonnaies comporte des risques significatifs. Ce bot est fourni à titre éducatif et expérimental. N'investissez que ce que vous êtes prêt à perdre. L'auteur n'est pas responsable des pertes financières qui pourraient résulter de l'utilisation de ce bot.

## Licence

Ce projet est sous licence MIT. Voir le fichier LICENSE pour plus de détails.
