#!/bin/bash

# Script d'installation et de déploiement du bot de trading de memecoins avec fonction de copytrade

# Couleurs pour les messages
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Installation du bot de trading de memecoins avec fonction de copytrade ===${NC}"

# Vérifier si Python est installé
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}Python 3 n'est pas installé. Veuillez l'installer avant de continuer.${NC}"
    exit 1
fi

# Vérifier si pip est installé
if ! command -v pip3 &> /dev/null; then
    echo -e "${RED}pip3 n'est pas installé. Veuillez l'installer avant de continuer.${NC}"
    exit 1
fi

# Créer un environnement virtuel si nécessaire
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}Création de l'environnement virtuel...${NC}"
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo -e "${RED}Erreur lors de la création de l'environnement virtuel.${NC}"
        exit 1
    fi
fi

# Activer l'environnement virtuel
echo -e "${YELLOW}Activation de l'environnement virtuel...${NC}"
source venv/bin/activate

# Installer les dépendances
echo -e "${YELLOW}Installation des dépendances...${NC}"
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo -e "${RED}Erreur lors de l'installation des dépendances.${NC}"
    exit 1
fi

# Exécuter les tests pour vérifier que tout fonctionne
echo -e "${YELLOW}Exécution des tests...${NC}"
python -m unittest tests/test_trading_bot.py
if [ $? -ne 0 ]; then
    echo -e "${RED}Certains tests ont échoué. Veuillez vérifier les erreurs avant de déployer le bot.${NC}"
    exit 1
fi

# Créer le répertoire de logs s'il n'existe pas
if [ ! -d "logs" ]; then
    echo -e "${YELLOW}Création du répertoire de logs...${NC}"
    mkdir -p logs
fi

# Créer le répertoire de données s'il n'existe pas
if [ ! -d "data" ]; then
    echo -e "${YELLOW}Création du répertoire de données...${NC}"
    mkdir -p data
fi

echo -e "${GREEN}Installation terminée avec succès!${NC}"
echo -e "${YELLOW}Pour démarrer le bot, exécutez: ./start_bot.sh${NC}"
