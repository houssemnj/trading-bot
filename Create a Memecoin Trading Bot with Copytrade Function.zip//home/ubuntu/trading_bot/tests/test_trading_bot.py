"""
Tests unitaires pour le bot de trading de memecoins avec fonction de copytrade.
"""

import unittest
import os
import sys
import json
from unittest.mock import MagicMock, patch
from datetime import datetime

# Ajouter le répertoire parent au chemin pour pouvoir importer les modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.trading_bot import TradingBot
from src.copytrade import CopytradeModule
from src.meme_trader import MemeTrader
from src.config import TRADING_CONFIG, COPYTRADE_CONFIG

class TestTradingBot(unittest.TestCase):
    """Tests pour la classe TradingBot."""
    
    def setUp(self):
        """Configuration initiale pour les tests."""
        # Créer une configuration de test
        self.test_config = {
            "dry_run": True,  # Toujours utiliser le mode simulation pour les tests
        }
        
        # Créer une instance du bot avec la configuration de test
        self.bot = TradingBot(self.test_config)
        
        # Mocker les échanges
        self.bot.exchanges = {
            "binance": MagicMock(),
            "coinbase": MagicMock(),
            "kraken": MagicMock()
        }
    
    def test_initialization(self):
        """Teste l'initialisation du bot."""
        self.assertIsNotNone(self.bot)
        self.assertFalse(self.bot.is_running)
        self.assertEqual(self.bot.active_trades, {})
        self.assertEqual(self.bot.trade_history, [])
    
    def test_get_market_data(self):
        """Teste la récupération des données de marché."""
        # Configurer le mock pour renvoyer des données de marché simulées
        mock_ohlcv = [
            [1616432400000, 0.06, 0.063, 0.058, 0.061, 1000],  # [timestamp, open, high, low, close, volume]
            [1616436000000, 0.061, 0.065, 0.06, 0.063, 1200]
        ]
        self.bot.exchanges["binance"].fetch_ohlcv.return_value = mock_ohlcv
        
        # Appeler la fonction à tester
        result = self.bot.get_market_data("binance", "DOGEUSDT", "1h", 2)
        
        # Vérifier que la fonction a été appelée avec les bons arguments
        self.bot.exchanges["binance"].fetch_ohlcv.assert_called_once_with("DOGEUSDT", "1h", limit=2)
        
        # Vérifier le résultat
        self.assertEqual(result, mock_ohlcv)
    
    def test_get_account_balance(self):
        """Teste la récupération du solde du compte."""
        # Configurer le mock pour renvoyer un solde simulé
        mock_balance = {
            "USDT": {"free": 1000, "used": 0, "total": 1000},
            "DOGE": {"free": 10000, "used": 0, "total": 10000}
        }
        self.bot.exchanges["binance"].fetch_balance.return_value = mock_balance
        
        # Appeler la fonction à tester
        result = self.bot.get_account_balance("binance", "USDT")
        
        # Vérifier que la fonction a été appelée
        self.bot.exchanges["binance"].fetch_balance.assert_called_once()
        
        # Vérifier le résultat
        self.assertEqual(result, mock_balance.get("USDT"))
    
    def test_place_order_dry_run(self):
        """Teste le placement d'un ordre en mode simulation."""
        # Appeler la fonction à tester
        result = self.bot.place_order(
            exchange_name="binance",
            symbol="DOGEUSDT",
            order_type="market",
            side="buy",
            amount=100,
            price=None
        )
        
        # Vérifier que l'échange n'a pas été appelé (mode dry run)
        self.bot.exchanges["binance"].create_market_buy_order.assert_not_called()
        
        # Vérifier que le résultat est un ordre simulé
        self.assertIsNotNone(result)
        self.assertTrue("dry_run" in result["info"])
        self.assertEqual(result["symbol"], "DOGEUSDT")
        self.assertEqual(result["type"], "market")
        self.assertEqual(result["side"], "buy")
        self.assertEqual(result["amount"], 100)
    
    def test_analyze_memecoin(self):
        """Teste l'analyse d'un memecoin."""
        # Configurer le mock pour renvoyer des données de marché simulées
        mock_ohlcv = [
            [1616432400000, 0.06, 0.063, 0.058, 0.061, 1000],
            [1616436000000, 0.061, 0.065, 0.06, 0.063, 1200],
            [1616439600000, 0.063, 0.067, 0.062, 0.065, 1500]
        ]
        self.bot.get_market_data = MagicMock(return_value=mock_ohlcv)
        
        # Appeler la fonction à tester
        result = self.bot.analyze_memecoin("binance", "DOGEUSDT")
        
        # Vérifier que la fonction a été appelée avec les bons arguments
        self.bot.get_market_data.assert_called_once_with("binance", "DOGEUSDT", timeframe='1h', limit=24)
        
        # Vérifier le résultat
        self.assertIsNotNone(result)
        self.assertEqual(result["symbol"], "DOGEUSDT")
        self.assertEqual(result["exchange"], "binance")
        self.assertEqual(result["current_price"], 0.065)
        self.assertIn("price_change_24h", result)
        self.assertIn("volatility_24h", result)
        self.assertIn("trend", result)


class TestCopytradeModule(unittest.TestCase):
    """Tests pour le module de copytrade."""
    
    def setUp(self):
        """Configuration initiale pour les tests."""
        # Créer un mock du bot de trading
        self.mock_trading_bot = MagicMock()
        
        # Créer une instance du module de copytrade
        self.copytrade = CopytradeModule(self.mock_trading_bot)
        
        # Configurer les attributs du module
        self.copytrade.followed_traders = []
        self.copytrade.trader_signals = {}
        self.copytrade.copied_trades = {}
    
    def test_initialization(self):
        """Teste l'initialisation du module de copytrade."""
        self.assertIsNotNone(self.copytrade)
        self.assertEqual(self.copytrade.trading_bot, self.mock_trading_bot)
        self.assertEqual(self.copytrade.followed_traders, [])
        self.assertEqual(self.copytrade.trader_signals, {})
        self.assertEqual(self.copytrade.copied_trades, {})
    
    def test_add_trader(self):
        """Teste l'ajout d'un trader à suivre."""
        # Appeler la fonction à tester
        result = self.copytrade.add_trader(
            trader_id="trader123",
            exchange="binance",
            allocation_pct=30.0,
            metadata={"name": "Trader Expert"}
        )
        
        # Vérifier le résultat
        self.assertTrue(result)
        self.assertEqual(len(self.copytrade.followed_traders), 1)
        self.assertEqual(self.copytrade.followed_traders[0]["id"], "trader123")
        self.assertEqual(self.copytrade.followed_traders[0]["exchange"], "binance")
        self.assertEqual(self.copytrade.followed_traders[0]["allocation_pct"], 30.0)
        self.assertEqual(self.copytrade.followed_traders[0]["metadata"]["name"], "Trader Expert")
    
    def test_remove_trader(self):
        """Teste la suppression d'un trader suivi."""
        # Ajouter un trader
        self.copytrade.followed_traders.append({
            "id": "trader123",
            "exchange": "binance",
            "allocation_pct": 30.0
        })
        
        # Appeler la fonction à tester
        result = self.copytrade.remove_trader("trader123")
        
        # Vérifier le résultat
        self.assertTrue(result)
        self.assertEqual(len(self.copytrade.followed_traders), 0)
    
    def test_process_trader_signal(self):
        """Teste le traitement d'un signal de trading."""
        # Ajouter un trader
        self.copytrade.followed_traders.append({
            "id": "trader123",
            "exchange": "binance",
            "allocation_pct": 30.0
        })
        
        # Configurer le mock pour renvoyer un ordre simulé
        mock_order = {
            "id": "order123",
            "symbol": "DOGEUSDT",
            "type": "market",
            "side": "buy",
            "amount": 100,
            "price": 0.065,
            "status": "closed"
        }
        self.mock_trading_bot.place_order.return_value = mock_order
        
        # Configurer le mock pour le solde du compte
        mock_balance = {"free": 1000, "used": 0, "total": 1000}
        self.mock_trading_bot.get_account_balance.return_value = mock_balance
        
        # Créer un signal de trading
        signal = {
            "type": "market",
            "symbol": "DOGEUSDT",
            "side": "buy",
            "price": 0.065,
            "amount": 100
        }
        
        # Appeler la fonction à tester
        with patch('time.sleep') as mock_sleep:  # Éviter d'attendre pendant les tests
            result = self.copytrade.process_trader_signal("trader123", signal)
        
        # Vérifier que la fonction a été appelée avec les bons arguments
        self.mock_trading_bot.place_order.assert_called_once()
        
        # Vérifier le résultat
        self.assertEqual(result, "order123")
        self.assertIn("trader123", self.copytrade.trader_signals)
        self.assertIn("order123", self.copytrade.copied_trades)
    
    def test_validate_signal(self):
        """Teste la validation d'un signal de trading."""
        # Signal valide
        valid_signal = {
            "type": "market",
            "symbol": "DOGEUSDT",
            "side": "buy",
            "price": 0.065,
            "amount": 100
        }
        
        # Signal invalide (champ manquant)
        invalid_signal_missing_field = {
            "type": "market",
            "symbol": "DOGEUSDT",
            "side": "buy",
            "price": 0.065
            # amount manquant
        }
        
        # Signal invalide (type invalide)
        invalid_signal_type = {
            "type": "invalid_type",
            "symbol": "DOGEUSDT",
            "side": "buy",
            "price": 0.065,
            "amount": 100
        }
        
        # Tester les signaux
        self.assertTrue(self.copytrade._validate_signal(valid_signal))
        self.assertFalse(self.copytrade._validate_signal(invalid_signal_missing_field))
        self.assertFalse(self.copytrade._validate_signal(invalid_signal_type))


class TestMemeTrader(unittest.TestCase):
    """Tests pour la classe MemeTrader."""
    
    def setUp(self):
        """Configuration initiale pour les tests."""
        # Patcher les classes dépendantes
        self.trading_bot_patcher = patch('src.meme_trader.TradingBot')
        self.copytrade_patcher = patch('src.meme_trader.CopytradeModule')
        
        # Obtenir les mocks
        self.mock_trading_bot_class = self.trading_bot_patcher.start()
        self.mock_copytrade_class = self.copytrade_patcher.start()
        
        # Configurer les mocks
        self.mock_trading_bot = MagicMock()
        self.mock_copytrade = MagicMock()
        self.mock_trading_bot_class.return_value = self.mock_trading_bot
        self.mock_copytrade_class.return_value = self.mock_copytrade
        
        # Créer une instance de MemeTrader
        self.meme_trader = MemeTrader()
    
    def tearDown(self):
        """Nettoyage après les tests."""
        self.trading_bot_patcher.stop()
        self.copytrade_patcher.stop()
    
    def test_initialization(self):
        """Teste l'initialisation de MemeTrader."""
        self.assertIsNotNone(self.meme_trader)
        self.assertEqual(self.meme_trader.trading_bot, self.mock_trading_bot)
        self.assertEqual(self.meme_trader.copytrade, self.mock_copytrade)
        self.assertFalse(self.meme_trader.is_running)
    
    def test_add_trader_to_follow(self):
        """Teste l'ajout d'un trader à suivre."""
        # Configurer le mock
        self.mock_copytrade.add_trader.return_value = True
        
        # Appeler la fonction à tester
        result = self.meme_trader.add_trader_to_follow(
            trader_id="trader123",
            exchange="binance",
            allocation_pct=30.0,
            metadata={"name": "Trader Expert"}
        )
        
        # Vérifier que la fonction a été appelée avec les bons arguments
        self.mock_copytrade.add_trader.assert_called_once_with(
            "trader123", "binance", 30.0, {"name": "Trader Expert"}
        )
        
        # Vérifier le résultat
        self.assertTrue(result)
    
    def test_analyze_all_memecoins(self):
        """Teste l'analyse de tous les memecoins."""
        # Configurer le mock
        mock_analysis = {
            "symbol": "DOGEUSDT",
            "exchange": "binance",
            "current_price": 0.065,
            "price_change_24h": 5.0,
            "volatility_24h": 2.5,
            "trend": "haussière"
        }
        self.mock_trading_bot.analyze_memecoin.return_value = mock_analysis
        
        # Utiliser return_value au lieu de side_effect pour simplifier
        self.mock_trading_bot.analyze_memecoin.return_value = mock_analysis
        
        # Appeler la fonction à tester
        result = self.meme_trader.analyze_all_memecoins()
        
        # Vérifier que la fonction a été appelée au moins une fois
        self.assertGreater(self.mock_trading_bot.analyze_memecoin.call_count, 0)
        
        # Vérifier le résultat
        self.assertIsNotNone(result)
        self.assertGreater(len(result), 0)
        self.assertEqual(result[0], mock_analysis)


if __name__ == '__main__':
    unittest.main()
