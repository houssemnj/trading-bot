#!/bin/bash

# Script d'exécution des tests pour le bot de trading de memecoins

# Créer le répertoire de tests s'il n'existe pas
mkdir -p tests

# Activer l'environnement virtuel
source venv/bin/activate

# Exécuter les tests unitaires
echo "Exécution des tests unitaires..."
python -m unittest tests/test_trading_bot.py

# Vérifier le résultat des tests
if [ $? -eq 0 ]; then
    echo "✅ Tous les tests ont réussi!"
else
    echo "❌ Certains tests ont échoué."
fi
