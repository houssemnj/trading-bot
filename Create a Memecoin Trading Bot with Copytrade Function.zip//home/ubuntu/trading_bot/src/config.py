"""
Configuration du bot de trading de memecoins avec fonction de copytrade.
"""

import os
from typing import Dict, List, Optional, Any

# Configuration des API d'échange
EXCHANGE_CONFIG = {
    "binance": {
        "api_key": os.environ.get("BINANCE_API_KEY", ""),
        "api_secret": os.environ.get("BINANCE_API_SECRET", ""),
        "testnet": True,  # Utiliser le testnet pour le développement
    },
    "coinbase": {
        "api_key": os.environ.get("COINBASE_API_KEY", ""),
        "api_secret": os.environ.get("COINBASE_API_SECRET", ""),
        "password": os.environ.get("COINBASE_API_PASSPHRASE", ""),
        "sandbox": True,  # Utiliser le sandbox pour le développement
    },
    "kraken": {
        "api_key": os.environ.get("KRAKEN_API_KEY", ""),
        "api_secret": os.environ.get("KRAKEN_API_SECRET", ""),
    }
}

# Configuration des paires de trading
TRADING_PAIRS = {
    "binance": [
        "DOGEUSDT",  # Dogecoin
        "SHIBUSDT",  # Shiba Inu
        "FLOKIUSDT", # Floki Inu
        "PEPEUSDT",  # Pepe
    ],
    "coinbase": [
        "DOGE-USD",  # Dogecoin
        "SHIB-USD",  # Shiba Inu
    ],
    "kraken": [
        "DOGE/USD",  # Dogecoin
        "SHIB/USD",  # Shiba Inu
    ]
}

# Configuration du trading
TRADING_CONFIG = {
    "default_exchange": "binance",
    "max_open_trades": 5,
    "stake_amount": 10.0,  # Montant en USD par trade
    "stake_currency": "USDT",
    "dry_run": True,  # Mode simulation
    "max_daily_trades": 20,
    "risk_level": "medium",  # low, medium, high
    "stop_loss_pct": 5.0,  # Pourcentage de stop loss
    "take_profit_pct": 10.0,  # Pourcentage de take profit
}

# Configuration du copytrade
COPYTRADE_CONFIG = {
    "enabled": True,
    "max_traders_to_follow": 3,
    "min_trader_reputation": 7.0,  # Score minimum sur 10
    "max_copy_stake_pct": 20.0,  # Pourcentage maximum du capital à allouer au copytrade
    "auto_adjust_position_size": True,  # Ajuster la taille des positions en fonction du capital
    "delay_seconds": 1.0,  # Délai en secondes avant de copier un trade
    "followed_traders": [
        # Liste des traders à suivre (à remplir par l'utilisateur)
        # {"id": "trader1", "exchange": "binance", "allocation_pct": 30},
        # {"id": "trader2", "exchange": "binance", "allocation_pct": 40},
        # {"id": "trader3", "exchange": "kraken", "allocation_pct": 30},
    ],
}

# Configuration des notifications
NOTIFICATION_CONFIG = {
    "enabled": True,
    "telegram": {
        "enabled": False,
        "token": os.environ.get("TELEGRAM_TOKEN", ""),
        "chat_id": os.environ.get("TELEGRAM_CHAT_ID", ""),
    },
    "email": {
        "enabled": False,
        "smtp_server": "smtp.gmail.com",
        "smtp_port": 587,
        "username": os.environ.get("EMAIL_USERNAME", ""),
        "password": os.environ.get("EMAIL_PASSWORD", ""),
        "from_email": os.environ.get("EMAIL_FROM", ""),
        "to_email": os.environ.get("EMAIL_TO", ""),
    },
    "notify_on": {
        "trade_open": True,
        "trade_close": True,
        "stop_loss": True,
        "take_profit": True,
        "error": True,
        "daily_summary": True,
    }
}

# Configuration de la journalisation
LOGGING_CONFIG = {
    "level": "INFO",  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    "log_to_file": True,
    "log_file": "trading_bot.log",
    "max_file_size": 10 * 1024 * 1024,  # 10 MB
    "backup_count": 5,
}

# Configuration de la base de données
DATABASE_CONFIG = {
    "type": "sqlite",  # sqlite, mysql, postgresql
    "path": "trading_bot.db",  # Pour sqlite
    "host": "localhost",  # Pour mysql/postgresql
    "port": 3306,  # Pour mysql/postgresql
    "username": "",  # Pour mysql/postgresql
    "password": "",  # Pour mysql/postgresql
    "database": "trading_bot",  # Pour mysql/postgresql
}
