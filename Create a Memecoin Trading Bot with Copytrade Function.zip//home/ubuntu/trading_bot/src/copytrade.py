"""
Module de copytrade pour le bot de trading de memecoins.
"""

import os
import time
import logging
import json
from typing import Dict, List, Optional, Any
from datetime import datetime

from src.config import COPYTRADE_CONFIG, TRADING_CONFIG

logger = logging.getLogger("CopytradeModule")

class CopytradeModule:
    """Module de copytrade pour le bot de trading de memecoins."""
    
    def __init__(self, trading_bot):
        """
        Initialise le module de copytrade.
        
        Args:
            trading_bot: Instance du bot de trading principal
        """
        self.trading_bot = trading_bot
        self.followed_traders = COPYTRADE_CONFIG["followed_traders"]
        self.max_traders = COPYTRADE_CONFIG["max_traders_to_follow"]
        self.min_reputation = COPYTRADE_CONFIG["min_trader_reputation"]
        self.max_stake_pct = COPYTRADE_CONFIG["max_copy_stake_pct"]
        self.auto_adjust = COPYTRADE_CONFIG["auto_adjust_position_size"]
        self.delay_seconds = COPYTRADE_CONFIG["delay_seconds"]
        self.enabled = COPYTRADE_CONFIG["enabled"]
        self.trader_signals = {}  # Stocke les derniers signaux reçus de chaque trader
        self.copied_trades = {}   # Stocke les trades copiés
        
        logger.info("Module de copytrade initialisé")
    
    def start(self):
        """Démarre le module de copytrade."""
        if not self.enabled:
            logger.info("Module de copytrade désactivé")
            return
        
        logger.info("Module de copytrade démarré")
        self._load_trader_data()
    
    def stop(self):
        """Arrête le module de copytrade."""
        logger.info("Module de copytrade arrêté")
        self._save_trader_data()
    
    def _load_trader_data(self):
        """Charge les données des traders suivis depuis un fichier."""
        try:
            if os.path.exists("trader_data.json"):
                with open("trader_data.json", "r") as f:
                    data = json.load(f)
                    self.trader_signals = data.get("signals", {})
                    self.copied_trades = data.get("trades", {})
                    logger.info(f"Données de {len(self.trader_signals)} traders chargées")
        except Exception as e:
            logger.error(f"Erreur lors du chargement des données des traders: {str(e)}")
    
    def _save_trader_data(self):
        """Sauvegarde les données des traders suivis dans un fichier."""
        try:
            data = {
                "signals": self.trader_signals,
                "trades": self.copied_trades
            }
            with open("trader_data.json", "w") as f:
                json.dump(data, f, indent=4)
            logger.info("Données des traders sauvegardées")
        except Exception as e:
            logger.error(f"Erreur lors de la sauvegarde des données des traders: {str(e)}")
    
    def add_trader(self, trader_id: str, exchange: str, allocation_pct: float, metadata: Dict = {}):
        """
        Ajoute un trader à suivre.
        
        Args:
            trader_id: Identifiant unique du trader
            exchange: Plateforme d'échange utilisée par le trader
            allocation_pct: Pourcentage du capital à allouer aux trades de ce trader
            metadata: Métadonnées supplémentaires sur le trader
        
        Returns:
            True si le trader a été ajouté, False sinon
        """
        # Vérifier si le nombre maximum de traders est atteint
        if len(self.followed_traders) >= self.max_traders:
            logger.warning(f"Nombre maximum de traders atteint ({self.max_traders})")
            return False
        
        # Vérifier si le trader existe déjà
        for trader in self.followed_traders:
            if trader["id"] == trader_id:
                logger.warning(f"Le trader {trader_id} est déjà suivi")
                return False
        
        # Ajouter le trader
        trader_data = {
            "id": trader_id,
            "exchange": exchange,
            "allocation_pct": allocation_pct,
            "added_date": datetime.now().isoformat(),
            "metadata": metadata
        }
        self.followed_traders.append(trader_data)
        logger.info(f"Trader {trader_id} ajouté avec une allocation de {allocation_pct}%")
        return True
    
    def remove_trader(self, trader_id: str):
        """
        Supprime un trader de la liste des traders suivis.
        
        Args:
            trader_id: Identifiant unique du trader
        
        Returns:
            True si le trader a été supprimé, False sinon
        """
        for i, trader in enumerate(self.followed_traders):
            if trader["id"] == trader_id:
                del self.followed_traders[i]
                logger.info(f"Trader {trader_id} supprimé")
                return True
        
        logger.warning(f"Trader {trader_id} non trouvé")
        return False
    
    def update_trader_allocation(self, trader_id: str, allocation_pct: float):
        """
        Met à jour l'allocation d'un trader.
        
        Args:
            trader_id: Identifiant unique du trader
            allocation_pct: Nouveau pourcentage d'allocation
        
        Returns:
            True si l'allocation a été mise à jour, False sinon
        """
        for trader in self.followed_traders:
            if trader["id"] == trader_id:
                trader["allocation_pct"] = allocation_pct
                logger.info(f"Allocation du trader {trader_id} mise à jour à {allocation_pct}%")
                return True
        
        logger.warning(f"Trader {trader_id} non trouvé")
        return False
    
    def process_trader_signal(self, trader_id: str, signal: Dict):
        """
        Traite un signal de trading reçu d'un trader suivi.
        
        Args:
            trader_id: Identifiant unique du trader
            signal: Signal de trading (contient type, symbole, prix, etc.)
        
        Returns:
            ID du trade copié ou None si le signal n'a pas été traité
        """
        if not self.enabled:
            logger.info("Module de copytrade désactivé, signal ignoré")
            return None
        
        # Vérifier si le trader est suivi
        trader_data = None
        for trader in self.followed_traders:
            if trader["id"] == trader_id:
                trader_data = trader
                break
        
        if not trader_data:
            logger.warning(f"Signal reçu d'un trader non suivi: {trader_id}")
            return None
        
        # Enregistrer le signal
        signal["timestamp"] = datetime.now().isoformat()
        self.trader_signals[trader_id] = signal
        
        # Vérifier si le signal est valide
        if not self._validate_signal(signal):
            logger.warning(f"Signal invalide reçu du trader {trader_id}")
            return None
        
        # Appliquer le délai configuré
        if self.delay_seconds > 0:
            logger.info(f"Attente de {self.delay_seconds} secondes avant de copier le trade")
            time.sleep(self.delay_seconds)
        
        # Copier le trade
        return self._copy_trade(trader_data, signal)
    
    def _validate_signal(self, signal: Dict) -> bool:
        """
        Valide un signal de trading.
        
        Args:
            signal: Signal de trading à valider
            
        Returns:
            True si le signal est valide, False sinon
        """
        required_fields = ["type", "symbol", "side", "price", "amount"]
        for field in required_fields:
            if field not in signal:
                logger.warning(f"Champ requis manquant dans le signal: {field}")
                return False
        
        valid_types = ["market", "limit"]
        if signal["type"] not in valid_types:
            logger.warning(f"Type de signal invalide: {signal['type']}")
            return False
        
        valid_sides = ["buy", "sell"]
        if signal["side"] not in valid_sides:
            logger.warning(f"Côté de signal invalide: {signal['side']}")
            return False
        
        return True
    
    def _copy_trade(self, trader_data: Dict, signal: Dict):
        """
        Copie un trade à partir d'un signal.
        
        Args:
            trader_data: Données du trader
            signal: Signal de trading
            
        Returns:
            ID du trade copié ou None si le trade n'a pas été copié
        """
        exchange_name = trader_data["exchange"]
        symbol = signal["symbol"]
        order_type = signal["type"]
        side = signal["side"]
        price = signal.get("price")
        original_amount = signal["amount"]
        
        # Calculer le montant à trader en fonction de l'allocation
        allocation_pct = trader_data["allocation_pct"]
        max_stake_pct = self.max_stake_pct
        
        # Limiter l'allocation au maximum configuré
        effective_allocation = min(allocation_pct, max_stake_pct)
        
        # Calculer le montant à trader
        if self.auto_adjust:
            # Ajuster le montant en fonction du capital disponible
            balance = self.trading_bot.get_account_balance(exchange_name, TRADING_CONFIG["stake_currency"])
            if not balance or "free" not in balance:
                logger.error(f"Impossible de récupérer le solde sur {exchange_name}")
                return None
            
            available_capital = balance["free"]
            stake_amount = available_capital * (effective_allocation / 100)
            
            # Limiter au montant maximum par trade
            max_stake = TRADING_CONFIG["stake_amount"]
            stake_amount = min(stake_amount, max_stake)
            
            # Calculer la quantité en fonction du prix
            amount = stake_amount / price if price else stake_amount
        else:
            # Utiliser le même montant que le trader, ajusté par l'allocation
            amount = original_amount * (effective_allocation / 100)
        
        # Placer l'ordre
        logger.info(f"Copie du trade du trader {trader_data['id']}: {side} {amount} {symbol} à {price if price else 'prix du marché'}")
        
        # Paramètres supplémentaires
        params = signal.get("params", {})
        
        # Placer l'ordre
        order = self.trading_bot.place_order(
            exchange_name=exchange_name,
            symbol=symbol,
            order_type=order_type,
            side=side,
            amount=amount,
            price=price,
            params=params
        )
        
        if not order:
            logger.error(f"Échec de la copie du trade du trader {trader_data['id']}")
            return None
        
        # Enregistrer le trade copié
        trade_id = order["id"]
        self.copied_trades[trade_id] = {
            "trader_id": trader_data["id"],
            "signal": signal,
            "order": order,
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Trade copié avec succès: {trade_id}")
        return trade_id
    
    def get_trader_performance(self, trader_id: str, period: str = "all"):
        """
        Calcule la performance d'un trader suivi.
        
        Args:
            trader_id: Identifiant unique du trader
            period: Période de calcul (all, day, week, month)
            
        Returns:
            Statistiques de performance du trader
        """
        # Filtrer les trades copiés pour ce trader
        trader_trades = [trade for trade_id, trade in self.copied_trades.items() 
                         if trade["trader_id"] == trader_id]
        
        if not trader_trades:
            logger.warning(f"Aucun trade trouvé pour le trader {trader_id}")
            return {
                "trader_id": trader_id,
                "total_trades": 0,
                "win_rate": 0,
                "profit_loss": 0,
                "avg_profit": 0
            }
        
        # Filtrer par période si nécessaire
        if period != "all":
            now = datetime.now()
            filtered_trades = []
            
            for trade in trader_trades:
                trade_time = datetime.fromisoformat(trade["timestamp"])
                if period == "day" and (now - trade_time).days <= 1:
                    filtered_trades.append(trade)
                elif period == "week" and (now - trade_time).days <= 7:
                    filtered_trades.append(trade)
                elif period == "month" and (now - trade_time).days <= 30:
                    filtered_trades.append(trade)
            
            trader_trades = filtered_trades
        
        # Calculer les statistiques
        total_trades = len(trader_trades)
        winning_trades = sum(1 for trade in trader_trades if trade.get("profit", 0) > 0)
        win_rate = (winning_trades / total_trades) * 100 if total_trades > 0 else 0
        
        total_profit = sum(trade.get("profit", 0) for trade in trader_trades)
        avg_profit = total_profit / total_trades if total_trades > 0 else 0
        
        return {
            "trader_id": trader_id,
            "total_trades": total_trades,
            "win_rate": win_rate,
            "profit_loss": total_profit,
            "avg_profit": avg_profit
        }
    
    def get_all_trader_performances(self, period: str = "all"):
        """
        Calcule la performance de tous les traders suivis.
        
        Args:
            period: Période de calcul (all, day, week, month)
            
        Returns:
            Liste des statistiques de performance de tous les traders
        """
        performances = []
        for trader in self.followed_traders:
            performance = self.get_trader_performance(trader["id"], period)
            performances.append(performance)
        
        return performances
    
    def update(self):
        """Met à jour le module de copytrade."""
        if not self.enabled:
            return
        
        # Vérifier les nouveaux signaux des traders suivis
        for trader in self.followed_traders:
            trader_id = trader["id"]
            # Cette fonction serait appelée par un système externe qui reçoit les signaux
            # des traders suivis, par exemple via une API ou un webhook
            
            # Mettre à jour les performances des traders
            self.get_trader_performance(trader_id)
        
        # Sauvegarder les données périodiquement
        self._save_trader_data()
