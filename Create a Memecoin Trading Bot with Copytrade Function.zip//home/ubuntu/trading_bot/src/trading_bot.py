"""
Classe principale du bot de trading de memecoins avec fonction de copytrade.
"""

import os
import time
import logging
import ccxt
from typing import Dict, List, Optional, Any
from datetime import datetime

from src.config import (
    EXCHANGE_CONFIG, 
    TRADING_PAIRS, 
    TRADING_CONFIG, 
    COPYTRADE_CONFIG,
    NOTIFICATION_CONFIG,
    LOGGING_CONFIG
)

# Configuration du logging
logging.basicConfig(
    level=getattr(logging, LOGGING_CONFIG["level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(LOGGING_CONFIG["log_file"]) if LOGGING_CONFIG["log_to_file"] else logging.NullHandler()
    ]
)
logger = logging.getLogger("TradingBot")

class TradingBot:
    """Bot de trading de memecoins avec fonction de copytrade."""
    
    def __init__(self, config_override: Optional[Dict[str, Any]] = None):
        """
        Initialise le bot de trading.
        
        Args:
            config_override: Dictionnaire pour remplacer les valeurs de configuration par défaut
        """
        self.exchanges = {}
        self.active_trades = {}
        self.trade_history = []
        self.is_running = False
        self.last_update_time = datetime.now()
        
        # Appliquer les remplacements de configuration si fournis
        if config_override:
            for key, value in config_override.items():
                if hasattr(self, key):
                    setattr(self, key, value)
        
        logger.info("Initialisation du bot de trading de memecoins")
        self._initialize_exchanges()
    
    def _initialize_exchanges(self):
        """Initialise les connexions aux plateformes d'échange."""
        for exchange_name, config in EXCHANGE_CONFIG.items():
            if not config["api_key"] or not config["api_secret"]:
                logger.warning(f"Clés API manquantes pour {exchange_name}, utilisation en mode lecture seule")
            
            try:
                if exchange_name == "binance":
                    exchange_class = getattr(ccxt, exchange_name)
                    exchange = exchange_class({
                        'apiKey': config["api_key"],
                        'secret': config["api_secret"],
                        'enableRateLimit': True,
                        'options': {
                            'defaultType': 'spot',
                            'adjustForTimeDifference': True,
                            'testnet': config.get("testnet", False)
                        }
                    })
                elif exchange_name == "coinbase":
                    exchange_class = getattr(ccxt, "coinbasepro")
                    exchange = exchange_class({
                        'apiKey': config["api_key"],
                        'secret': config["api_secret"],
                        'password': config.get("password", ""),
                        'enableRateLimit': True,
                        'options': {
                            'adjustForTimeDifference': True,
                            'sandboxMode': config.get("sandbox", False)
                        }
                    })
                else:
                    exchange_class = getattr(ccxt, exchange_name)
                    exchange = exchange_class({
                        'apiKey': config["api_key"],
                        'secret': config["api_secret"],
                        'enableRateLimit': True,
                    })
                
                # Vérifier la connexion
                exchange.load_markets()
                self.exchanges[exchange_name] = exchange
                logger.info(f"Connexion établie avec {exchange_name}")
                
            except Exception as e:
                logger.error(f"Erreur lors de la connexion à {exchange_name}: {str(e)}")
    
    def get_market_data(self, exchange_name: str, symbol: str, timeframe: str = '1h', limit: int = 100):
        """
        Récupère les données de marché pour un symbole spécifique.
        
        Args:
            exchange_name: Nom de la plateforme d'échange
            symbol: Symbole de la paire de trading
            timeframe: Intervalle de temps (1m, 5m, 15m, 1h, 4h, 1d, etc.)
            limit: Nombre de bougies à récupérer
            
        Returns:
            Liste de bougies OHLCV (Open, High, Low, Close, Volume)
        """
        if exchange_name not in self.exchanges:
            logger.error(f"Échange {exchange_name} non initialisé")
            return None
        
        try:
            exchange = self.exchanges[exchange_name]
            ohlcv = exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
            return ohlcv
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des données de marché pour {symbol} sur {exchange_name}: {str(e)}")
            return None
    
    def get_account_balance(self, exchange_name: str, currency: Optional[str] = None):
        """
        Récupère le solde du compte pour une devise spécifique ou toutes les devises.
        
        Args:
            exchange_name: Nom de la plateforme d'échange
            currency: Code de la devise (optionnel)
            
        Returns:
            Solde du compte pour la devise spécifiée ou toutes les devises
        """
        if exchange_name not in self.exchanges:
            logger.error(f"Échange {exchange_name} non initialisé")
            return None
        
        try:
            exchange = self.exchanges[exchange_name]
            balance = exchange.fetch_balance()
            
            if currency:
                return balance.get(currency, {})
            else:
                return balance
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du solde sur {exchange_name}: {str(e)}")
            return None
    
    def place_order(self, exchange_name: str, symbol: str, order_type: str, side: str, 
                   amount: float, price: Optional[float] = None, params: Dict = {}):
        """
        Place un ordre sur la plateforme d'échange.
        
        Args:
            exchange_name: Nom de la plateforme d'échange
            symbol: Symbole de la paire de trading
            order_type: Type d'ordre (market, limit)
            side: Côté de l'ordre (buy, sell)
            amount: Quantité à acheter/vendre
            price: Prix pour les ordres limit (optionnel)
            params: Paramètres supplémentaires pour l'ordre
            
        Returns:
            Détails de l'ordre placé
        """
        if TRADING_CONFIG["dry_run"]:
            logger.info(f"[DRY RUN] Ordre simulé: {side} {amount} {symbol} à {price if price else 'prix du marché'}")
            # Simuler un ordre en dry run
            current_time = int(time.time() * 1000)
            simulated_order = {
                'id': f'dry-run-{current_time}',
                'timestamp': current_time,
                'datetime': datetime.fromtimestamp(current_time / 1000).isoformat(),
                'symbol': symbol,
                'type': order_type,
                'side': side,
                'price': price if price else 0,
                'amount': amount,
                'cost': price * amount if price else 0,
                'status': 'closed',
                'fee': {
                    'cost': 0,
                    'currency': symbol.split('/')[1] if '/' in symbol else symbol[-4:],
                },
                'info': {'dry_run': True}
            }
            return simulated_order
        
        if exchange_name not in self.exchanges:
            logger.error(f"Échange {exchange_name} non initialisé")
            return None
        
        try:
            exchange = self.exchanges[exchange_name]
            
            if order_type == 'market':
                if side == 'buy':
                    order = exchange.create_market_buy_order(symbol, amount, params)
                else:
                    order = exchange.create_market_sell_order(symbol, amount, params)
            elif order_type == 'limit':
                if not price:
                    logger.error("Prix requis pour les ordres limit")
                    return None
                
                if side == 'buy':
                    order = exchange.create_limit_buy_order(symbol, amount, price, params)
                else:
                    order = exchange.create_limit_sell_order(symbol, amount, price, params)
            else:
                logger.error(f"Type d'ordre non pris en charge: {order_type}")
                return None
            
            logger.info(f"Ordre placé: {side} {amount} {symbol} à {price if price else 'prix du marché'}")
            return order
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre sur {exchange_name}: {str(e)}")
            return None
    
    def cancel_order(self, exchange_name: str, order_id: str, symbol: str):
        """
        Annule un ordre existant.
        
        Args:
            exchange_name: Nom de la plateforme d'échange
            order_id: ID de l'ordre à annuler
            symbol: Symbole de la paire de trading
            
        Returns:
            Résultat de l'annulation
        """
        if TRADING_CONFIG["dry_run"]:
            logger.info(f"[DRY RUN] Annulation simulée de l'ordre {order_id}")
            return {'id': order_id, 'status': 'canceled'}
        
        if exchange_name not in self.exchanges:
            logger.error(f"Échange {exchange_name} non initialisé")
            return None
        
        try:
            exchange = self.exchanges[exchange_name]
            result = exchange.cancel_order(order_id, symbol)
            logger.info(f"Ordre {order_id} annulé")
            return result
        except Exception as e:
            logger.error(f"Erreur lors de l'annulation de l'ordre {order_id} sur {exchange_name}: {str(e)}")
            return None
    
    def get_order_status(self, exchange_name: str, order_id: str, symbol: str):
        """
        Récupère le statut d'un ordre.
        
        Args:
            exchange_name: Nom de la plateforme d'échange
            order_id: ID de l'ordre
            symbol: Symbole de la paire de trading
            
        Returns:
            Détails de l'ordre
        """
        if exchange_name not in self.exchanges:
            logger.error(f"Échange {exchange_name} non initialisé")
            return None
        
        try:
            exchange = self.exchanges[exchange_name]
            order = exchange.fetch_order(order_id, symbol)
            return order
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du statut de l'ordre {order_id} sur {exchange_name}: {str(e)}")
            return None
    
    def start(self):
        """Démarre le bot de trading."""
        if self.is_running:
            logger.warning("Le bot est déjà en cours d'exécution")
            return
        
        self.is_running = True
        logger.info("Bot de trading démarré")
        
        try:
            while self.is_running:
                self._update()
                time.sleep(1)  # Attendre 1 seconde entre les mises à jour
        except KeyboardInterrupt:
            logger.info("Arrêt du bot demandé par l'utilisateur")
        except Exception as e:
            logger.error(f"Erreur lors de l'exécution du bot: {str(e)}")
        finally:
            self.stop()
    
    def stop(self):
        """Arrête le bot de trading."""
        self.is_running = False
        logger.info("Bot de trading arrêté")
    
    def _update(self):
        """Met à jour l'état du bot et exécute les stratégies de trading."""
        current_time = datetime.now()
        
        # Mettre à jour les données de marché et exécuter les stratégies toutes les minutes
        if (current_time - self.last_update_time).total_seconds() >= 60:
            self.last_update_time = current_time
            logger.debug("Mise à jour des données de marché et exécution des stratégies")
            
            # Mettre à jour les données pour chaque paire de trading sur chaque échange
            for exchange_name, pairs in TRADING_PAIRS.items():
                if exchange_name not in self.exchanges:
                    continue
                
                for pair in pairs:
                    # Récupérer les données de marché
                    market_data = self.get_market_data(exchange_name, pair)
                    if not market_data:
                        continue
                    
                    # Exécuter les stratégies de trading (à implémenter)
                    # self._execute_strategies(exchange_name, pair, market_data)
            
            # Vérifier les ordres en cours
            self._check_active_trades()
    
    def _check_active_trades(self):
        """Vérifie l'état des trades actifs et applique les règles de gestion des risques."""
        for trade_id, trade in list(self.active_trades.items()):
            exchange_name = trade["exchange"]
            symbol = trade["symbol"]
            order_id = trade["order_id"]
            
            # Récupérer le statut de l'ordre
            order = self.get_order_status(exchange_name, order_id, symbol)
            if not order:
                continue
            
            # Mettre à jour le statut du trade
            trade["status"] = order["status"]
            
            # Si l'ordre est exécuté, appliquer les règles de gestion des risques
            if order["status"] == "closed":
                # Vérifier si un stop loss ou take profit doit être placé
                if trade["side"] == "buy" and not trade.get("stop_loss_order_id"):
                    self._place_stop_loss(trade)
                
                # Si c'est un ordre de vente qui est exécuté, le trade est terminé
                if trade["side"] == "sell":
                    logger.info(f"Trade {trade_id} terminé")
                    self.trade_history.append(trade)
                    del self.active_trades[trade_id]
    
    def _place_stop_loss(self, trade):
        """Place un ordre stop loss pour un trade."""
        exchange_name = trade["exchange"]
        symbol = trade["symbol"]
        entry_price = trade["price"]
        amount = trade["amount"]
        
        # Calculer le prix du stop loss
        stop_loss_pct = TRADING_CONFIG["stop_loss_pct"] / 100
        stop_loss_price = entry_price * (1 - stop_loss_pct)
        
        # Placer l'ordre stop loss
        params = {"stopPrice": stop_loss_price}
        stop_order = self.place_order(
            exchange_name=exchange_name,
            symbol=symbol,
            order_type="stop_market",
            side="sell",
            amount=amount,
            params=params
        )
        
        if stop_order:
            trade["stop_loss_order_id"] = stop_order["id"]
            trade["stop_loss_price"] = stop_loss_price
            logger.info(f"Stop loss placé pour le trade {trade['id']} à {stop_loss_price}")
    
    def analyze_memecoin(self, exchange_name: str, symbol: str):
        """
        Analyse un memecoin spécifique pour déterminer s'il faut trader.
        
        Args:
            exchange_name: Nom de la plateforme d'échange
            symbol: Symbole de la paire de trading
            
        Returns:
            Dictionnaire contenant les résultats de l'analyse
        """
        # Récupérer les données de marché
        market_data = self.get_market_data(exchange_name, symbol, timeframe='1h', limit=24)
        if not market_data:
            return None
        
        # Analyser les données (exemple simple)
        closes = [candle[4] for candle in market_data]
        current_price = closes[-1]
        
        # Calculer quelques indicateurs de base
        avg_pric<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>