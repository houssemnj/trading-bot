"""
Intégration du module de copytrade dans le bot de trading de memecoins.
"""

import os
import sys
import logging
from typing import Dict, List, Optional, Any

from src.trading_bot import TradingBot
from src.copytrade import CopytradeModule
from src.config import TRADING_CONFIG, COPYTRADE_CONFIG, LOGGING_CONFIG

# Configuration du logging
logging.basicConfig(
    level=getattr(logging, LOGGING_CONFIG["level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(LOGGING_CONFIG["log_file"]) if LOGGING_CONFIG["log_to_file"] else logging.NullHandler()
    ]
)
logger = logging.getLogger("MemeTrader")

class MemeTrader:
    """Bot de trading de memecoins avec fonction de copytrade intégrée."""
    
    def __init__(self, config_override: Optional[Dict[str, Any]] = None):
        """
        Initialise le bot de trading de memecoins avec fonction de copytrade.
        
        Args:
            config_override: Dictionnaire pour remplacer les valeurs de configuration par défaut
        """
        logger.info("Initialisation du bot de trading de memecoins avec fonction de copytrade")
        
        # Initialiser le bot de trading principal
        self.trading_bot = TradingBot(config_override)
        
        # Initialiser le module de copytrade
        self.copytrade = CopytradeModule(self.trading_bot)
        
        # État du bot
        self.is_running = False
    
    def start(self):
        """Démarre le bot de trading de memecoins avec fonction de copytrade."""
        if self.is_running:
            logger.warning("Le bot est déjà en cours d'exécution")
            return
        
        logger.info("Démarrage du bot de trading de memecoins avec fonction de copytrade")
        
        # Démarrer le module de copytrade
        if COPYTRADE_CONFIG["enabled"]:
            self.copytrade.start()
        
        # Démarrer le bot de trading principal
        self.is_running = True
        self.trading_bot.is_running = True
        
        try:
            # Boucle principale
            self._run_main_loop()
        except KeyboardInterrupt:
            logger.info("Arrêt du bot demandé par l'utilisateur")
        except Exception as e:
            logger.error(f"Erreur lors de l'exécution du bot: {str(e)}")
        finally:
            self.stop()
    
    def stop(self):
        """Arrête le bot de trading de memecoins avec fonction de copytrade."""
        logger.info("Arrêt du bot de trading de memecoins avec fonction de copytrade")
        
        # Arrêter le module de copytrade
        if COPYTRADE_CONFIG["enabled"]:
            self.copytrade.stop()
        
        # Arrêter le bot de trading principal
        self.trading_bot.stop()
        
        self.is_running = False
    
    def _run_main_loop(self):
        """Exécute la boucle principale du bot."""
        import time
        
        while self.is_running:
            # Mettre à jour le bot de trading principal
            self.trading_bot._update()
            
            # Mettre à jour le module de copytrade
            if COPYTRADE_CONFIG["enabled"]:
                self.copytrade.update()
            
            # Attendre avant la prochaine mise à jour
            time.sleep(1)
    
    def add_trader_to_follow(self, trader_id: str, exchange: str, allocation_pct: float, metadata: Dict = {}):
        """
        Ajoute un trader à suivre pour le copytrade.
        
        Args:
            trader_id: Identifiant unique du trader
            exchange: Plateforme d'échange utilisée par le trader
            allocation_pct: Pourcentage du capital à allouer aux trades de ce trader
            metadata: Métadonnées supplémentaires sur le trader
            
        Returns:
            True si le trader a été ajouté, False sinon
        """
        if not COPYTRADE_CONFIG["enabled"]:
            logger.warning("Le module de copytrade est désactivé")
            return False
        
        return self.copytrade.add_trader(trader_id, exchange, allocation_pct, metadata)
    
    def remove_trader_from_follow(self, trader_id: str):
        """
        Supprime un trader de la liste des traders suivis.
        
        Args:
            trader_id: Identifiant unique du trader
            
        Returns:
            True si le trader a été supprimé, False sinon
        """
        if not COPYTRADE_CONFIG["enabled"]:
            logger.warning("Le module de copytrade est désactivé")
            return False
        
        return self.copytrade.remove_trader(trader_id)
    
    def get_trader_performances(self, period: str = "all"):
        """
        Récupère les performances des traders suivis.
        
        Args:
            period: Période de calcul (all, day, week, month)
            
        Returns:
            Liste des statistiques de performance des traders suivis
        """
        if not COPYTRADE_CONFIG["enabled"]:
            logger.warning("Le module de copytrade est désactivé")
            return []
        
        return self.copytrade.get_all_trader_performances(period)
    
    def process_external_signal(self, trader_id: str, signal: Dict):
        """
        Traite un signal de trading externe.
        
        Args:
            trader_id: Identifiant unique du trader
            signal: Signal de trading (contient type, symbole, prix, etc.)
            
        Returns:
            ID du trade copié ou None si le signal n'a pas été traité
        """
        if not COPYTRADE_CONFIG["enabled"]:
            logger.warning("Le module de copytrade est désactivé")
            return None
        
        return self.copytrade.process_trader_signal(trader_id, signal)
    
    def analyze_all_memecoins(self):
        """
        Analyse tous les memecoins configurés.
        
        Returns:
            Liste des résultats d'analyse pour chaque memecoin
        """
        from src.config import TRADING_PAIRS
        
        results = []
        
        for exchange_name, pairs in TRADING_PAIRS.items():
            for pair in pairs:
                analysis = self.trading_bot.analyze_memecoin(exchange_name, pair)
                if analysis:
                    results.append(analysis)
        
        return results
    
    def get_account_balances(self):
        """
        Récupère les soldes de tous les comptes configurés.
        
        Returns:
            Dictionnaire des soldes par plateforme d'échange
        """
        balances = {}
        
        for exchange_name in self.trading_bot.exchanges:
            balance = self.trading_bot.get_account_balance(exchange_name)
            if balance:
                balances[exchange_name] = balance
        
        return balances

# Point d'entrée pour l'exécution directe
if __name__ == "__main__":
    # Créer le bot de trading de memecoins avec fonction de copytrade
    meme_trader = MemeTrader()
    
    # Exemple d'ajout d'un trader à suivre
    if COPYTRADE_CONFIG["enabled"]:
        meme_trader.add_trader_to_follow(
            trader_id="trader123",
            exchange="binance",
            allocation_pct=30.0,
            metadata={"name": "Trader Expert", "description": "Trader spécialisé dans les memecoins"}
        )
    
    # Exemple d'analyse de tous les memecoins
    analyses = meme_trader.analyze_all_memecoins()
    for analysis in analyses:
        print(f"Analyse de {analysis['symbol']}:")
        print(f"Prix actuel: {analysis['current_price']}")
        print(f"Variation sur 24h: {analysis['price_change_24h']:.2f}%")
        print(f"Volatilité sur 24h: {analysis['volatility_24h']:.2f}%")
        print(f"Tendance: {analysis['trend']}")
        print("---")
    
    # Démarrer le bot (décommenter pour exécuter)
    # meme_trader.start()
