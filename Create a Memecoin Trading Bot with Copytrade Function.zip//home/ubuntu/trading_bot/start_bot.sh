#!/bin/bash

# Script de démarrage du bot de trading de memecoins avec fonction de copytrade

# Couleurs pour les messages
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Démarrage du bot de trading de memecoins avec fonction de copytrade ===${NC}"

# Vérifier si l'environnement virtuel existe
if [ ! -d "venv" ]; then
    echo -e "${RED}L'environnement virtuel n'existe pas. Veuillez exécuter install.sh d'abord.${NC}"
    exit 1
fi

# Activer l'environnement virtuel
echo -e "${YELLOW}Activation de l'environnement virtuel...${NC}"
source venv/bin/activate

# Vérifier si le fichier de configuration existe
if [ ! -f "src/config.py" ]; then
    echo -e "${RED}Le fichier de configuration n'existe pas.${NC}"
    exit 1
fi

# Vérifier si les clés API sont configurées
API_KEYS_SET=$(grep -c "os.environ.get" src/config.py)
if [ $API_KEYS_SET -gt 0 ]; then
    echo -e "${YELLOW}Attention: Les clés API sont configurées pour être récupérées depuis les variables d'environnement.${NC}"
    echo -e "${YELLOW}Assurez-vous que les variables d'environnement suivantes sont définies:${NC}"
    echo -e "${YELLOW}- BINANCE_API_KEY${NC}"
    echo -e "${YELLOW}- BINANCE_API_SECRET${NC}"
    echo -e "${YELLOW}- COINBASE_API_KEY${NC}"
    echo -e "${YELLOW}- COINBASE_API_SECRET${NC}"
    echo -e "${YELLOW}- KRAKEN_API_KEY${NC}"
    echo -e "${YELLOW}- KRAKEN_API_SECRET${NC}"
    
    # Demander confirmation
    read -p "Voulez-vous continuer? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo -e "${RED}Démarrage annulé.${NC}"
        exit 1
    fi
fi

# Démarrer le bot
echo -e "${GREEN}Démarrage du bot...${NC}"
echo -e "${YELLOW}Les logs seront enregistrés dans logs/trading_bot.log${NC}"
echo -e "${YELLOW}Appuyez sur Ctrl+C pour arrêter le bot${NC}"

# Exécuter le bot
python -m src.meme_trader

# Désactiver l'environnement virtuel à la sortie
deactivate
