#!/bin/bash

# Script d'arrêt du bot de trading de memecoins avec fonction de copytrade

# Couleurs pour les messages
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}=== Arrêt du bot de trading de memecoins avec fonction de copytrade ===${NC}"

# Vérifier si le bot est en cours d'exécution
PID=$(pgrep -f "python -m src.meme_trader")

if [ -z "$PID" ]; then
    echo -e "${RED}Le bot ne semble pas être en cours d'exécution.${NC}"
    exit 1
fi

# Arrêter le bot
echo -e "${YELLOW}Arrêt du bot (PID: $PID)...${NC}"
kill $PID

# Vérifier si l'arrêt a réussi
sleep 2
if ps -p $PID > /dev/null; then
    echo -e "${RED}Le bot n'a pas pu être arrêté proprement. Tentative d'arrêt forcé...${NC}"
    kill -9 $PID
    sleep 1
    if ps -p $PID > /dev/null; then
        echo -e "${RED}Impossible d'arrêter le bot. Veuillez vérifier manuellement.${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}Le bot a été arrêté avec succès.${NC}"
